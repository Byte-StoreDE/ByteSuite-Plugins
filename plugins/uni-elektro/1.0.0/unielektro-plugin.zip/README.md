# Uni-Elektro Server Plugin

Serverseitiges Plugin für den Produktimport von [Uni-Elektro](https://www.unielektro.de).

## Beschreibung

Dieses Plugin stellt eine Fastify-Plugin-Schnittstelle bereit, um Produkte von Uni-Elektro zu durchsuchen und zu importieren. Es nutzt die Uni-Elektro Suggest-API und extrahiert detaillierte Produktdaten (EAN, Hersteller-Artikelnummer) von den Produktseiten.

## API-Endpunkte

Nach dem Registrieren des Plugins im Backend sind folgende Routen verfügbar:

### `GET /api/plugins/unielektro/info`

Gibt die Plugin-Informationen zurück.

**Antwort:**
```json
{
  "id": "uni-elektro",
  "name": "Uni-Elektro",
  "version": "1.0.0",
  "description": "Produkte von Uni-Elektro durchsuchen und importieren"
}
```

### `GET /api/plugins/unielektro/search?q=QUERY`

Sucht Produkte über die Uni-Elektro Suggest-API.

**Parameter:**
- `q` (required): Suchbegriff (mindestens 2 Zeichen)

**Antwort:**
```json
{
  "products": [
    {
      "id": "/MERTEN-MEG2301-0319-Steckdose--item-02039483",
      "sku": "MEG2301-0319",
      "name": "Steckdose polarweiß glänzen",
      "manufacturer": "MERTEN",
      "ean": "4042811032975",
      "imageUrl": "https://...",
      "sourceUrl": "https://www.unielektro.de/...",
      "source": "Uni-Elektro"
    }
  ],
  "total": 1,
  "hasMore": false
}
```

### `GET /api/plugins/unielektro/product/:productId`

Lädt detaillierte Informationen zu einem einzelnen Produkt.

**Parameter:**
- `productId` (required): Der Produkt-Pfad (z. B. `MERTEN-478219-Rahmen--item-02036989`)

## Integration ins Backend

Um das Plugin im Backend zu registrieren:

```typescript
import { registerUniElektroPlugin } from '@byte-suite/plugin-unielektro';

// Im server.ts
await app.register(registerUniElektroPlugin);
```

## Build

```bash
npm run build --workspace=@byte-suite/plugin-unielektro
```

## Dateistruktur

```
apps/plugins/unielektro/
├── package.json
├── tsconfig.json
├── README.md
└── src/
    ├── index.ts      # Exports
    ├── types.ts      # TypeScript-Interfaces
    └── plugin.ts     # Fastify-Plugin + API-Logik
```
